const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const db = new DatabaseSync(path.join(ROOT, 'molo_opportunities.db'));

db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 full_name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 phone TEXT,
 password_hash TEXT NOT NULL,
 account_type TEXT NOT NULL DEFAULT 'jobseeker',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 type TEXT NOT NULL,
 title TEXT NOT NULL,
 company TEXT NOT NULL,
 location TEXT NOT NULL,
 mode TEXT NOT NULL,
 description TEXT DEFAULT '',
 deadline TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 job_id INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'Applied',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(user_id, job_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS sessions (
 token TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
`);

const count = db.prepare('SELECT COUNT(*) AS n FROM jobs').get().n;
if (count === 0) {
  const insert = db.prepare('INSERT INTO jobs(type,title,company,location,mode,description,deadline) VALUES(?,?,?,?,?,?,?)');
  const seed = [
    ['Job','Marketing Officer','Tony Company Ltd','Nakuru','Full-time','Drive retailer awareness, sales and marketing activities.','2026-10-15'],
    ['Internship','ICT Intern','St. Francis Motto Hope','Molo','Internship','Support computer systems, users and school ICT activities.','2026-10-20'],
    ['Attachment','Reprographic Assistant','Baraka College','Molo','Attachment','Assist with printing, document preparation and administrative support.','2026-10-25'],
    ['Volunteer','Youth Mentor','Molo Community Initiative','Molo','Volunteer','Support youth activities and community programs.','2026-10-30'],
    ['Job','Office Assistant','Lakeview Hotel','Molo','Part-time','Front-office and administrative support.','2026-10-18'],
    ['Internship','ICT Support Intern','Molo Technical College','Molo','Internship','Assist with ICT support and basic troubleshooting.','2026-10-22'],
    ['Job','Customer Service Agent','KCB Branch','Nakuru','Full-time','Customer support and service desk duties.','2026-10-12'],
    ['Job','Field Officer','NGO Kenya','Nakuru','Contract','Field data collection and community engagement.','2026-10-28']
  ];
  for (const row of seed) insert.run(...row);
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*'});
  res.end(body);
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return salt + ':' + crypto.scryptSync(password, salt, 64).toString('hex');
}
function verifyPassword(password, stored) {
  const [salt, key] = stored.split(':');
  if (!salt || !key) return false;
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key,'hex'), Buffer.from(derived,'hex'));
}
function parseBody(req) {
  return new Promise((resolve,reject)=>{
    let data='';
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', ()=> { try { resolve(data ? JSON.parse(data) : {}); } catch(e){ reject(e); } });
    req.on('error',reject);
  });
}
function getUser(req) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i,'');
  if (!token) return null;
  return db.prepare(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?`).get(token, Date.now());
}
function sendFile(res, file, type) {
  fs.readFile(path.join(ROOT,file),(err,data)=>{
    if(err){res.writeHead(404);return res.end('Not found');}
    res.writeHead(200,{'Content-Type':type}); res.end(data);
  });
}

const server = http.createServer(async (req,res)=>{
  try {
    if(req.method === 'OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end();}
    const url = new URL(req.url, `http://${req.headers.host}`);
    if(req.method === 'GET' && url.pathname === '/api/jobs'){
      const q=(url.searchParams.get('q')||'').toLowerCase(); const type=url.searchParams.get('type')||''; const loc=url.searchParams.get('location')||'';
      let rows=db.prepare('SELECT * FROM jobs ORDER BY id DESC').all();
      rows=rows.filter(j=>(!q || `${j.title} ${j.company} ${j.type} ${j.description}`.toLowerCase().includes(q)) && (!type || type==='All Categories' || j.type===type) && (!loc || loc==='Other Towns' || j.location===loc));
      return json(res,200,rows);
    }
    if(req.method === 'POST' && url.pathname === '/api/register'){
      const b=await parseBody(req); if(!b.fullName||!b.email||!b.password) return json(res,400,{error:'Name, email and password are required.'});
      try { const r=db.prepare('INSERT INTO users(full_name,email,phone,password_hash,account_type) VALUES(?,?,?,?,?)').run(b.fullName.trim(),b.email.trim().toLowerCase(),b.phone||'',hashPassword(b.password),b.accountType==='Employer'?'employer':'jobseeker'); return json(res,201,{message:'Account created',userId:Number(r.lastInsertRowid)}); }
      catch(e){ if(String(e.message).includes('UNIQUE')) return json(res,409,{error:'An account with that email already exists.'}); throw e; }
    }
    if(req.method === 'POST' && url.pathname === '/api/login'){
      const b=await parseBody(req); const u=db.prepare('SELECT * FROM users WHERE email=?').get((b.email||'').trim().toLowerCase());
      if(!u || !verifyPassword(b.password||'',u.password_hash)) return json(res,401,{error:'Invalid email or password.'});
      const token=crypto.randomBytes(32).toString('hex'); db.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').run(token,u.id,Date.now()+7*24*60*60*1000);
      return json(res,200,{token,user:{id:u.id,fullName:u.full_name,email:u.email,accountType:u.account_type}});
    }
    if(req.method === 'POST' && url.pathname === '/api/jobs'){
      const u=getUser(req); if(!u || u.account_type!=='employer') return json(res,403,{error:'Employer login required.'});
      const b=await parseBody(req); if(!b.title||!b.company||!b.location||!b.type||!b.mode) return json(res,400,{error:'Title, company, location, type and mode are required.'});
      const r=db.prepare('INSERT INTO jobs(type,title,company,location,mode,description,deadline) VALUES(?,?,?,?,?,?,?)').run(b.type,b.title,b.company,b.location,b.mode,b.description||'',b.deadline||'');
      return json(res,201,{message:'Vacancy posted',id:Number(r.lastInsertRowid)});
    }
    if(req.method === 'POST' && url.pathname.startsWith('/api/jobs/') && url.pathname.endsWith('/apply')){
      const u=getUser(req); if(!u) return json(res,401,{error:'Please log in before applying.'});
      const id=Number(url.pathname.split('/')[3]); if(!id) return json(res,400,{error:'Invalid job.'});
      try { db.prepare('INSERT INTO applications(user_id,job_id) VALUES(?,?)').run(u.id,id); return json(res,201,{message:'Application submitted'}); }
      catch(e){ if(String(e.message).includes('UNIQUE')) return json(res,409,{error:'You have already applied for this opportunity.'}); throw e; }
    }
    if(req.method === 'GET' && url.pathname === '/api/me'){
      const u=getUser(req); if(!u) return json(res,401,{error:'Not logged in'});
      const apps=db.prepare(`SELECT a.id,a.status,a.created_at,j.title,j.company,j.location FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.id DESC`).all(u.id);
      return json(res,200,{user:{id:u.id,fullName:u.full_name,email:u.email,accountType:u.account_type},applications:apps});
    }
    if(req.method === 'GET' && url.pathname === '/') return sendFile(res,'index.html','text/html; charset=utf-8');
    if(req.method === 'GET' && url.pathname === '/style.css') return sendFile(res,'style.css','text/css; charset=utf-8');
    if(req.method === 'GET' && url.pathname === '/script.js') return sendFile(res,'script.js','application/javascript; charset=utf-8');
    res.writeHead(404); res.end('Not found');
  } catch(e){ console.error(e); json(res,500,{error:'Server error'}); }
});
server.listen(PORT,()=>console.log(`Molo Opportunities running at http://localhost:${PORT}`));
